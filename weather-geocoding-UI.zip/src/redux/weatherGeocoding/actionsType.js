const weatherGeocodingActions = {
    FETCH_DATA: 'FETCH_DATA',
    ERROR_FETCH: 'ERROR_FETCH',
 };
  
  export default weatherGeocodingActions;
  